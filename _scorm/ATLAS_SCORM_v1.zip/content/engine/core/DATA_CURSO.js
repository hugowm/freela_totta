DATA_CURSO = {
    empresa : 'Atlas Schindler',
    nome_curso : 'Ética e Compliance',
    telas : [
        {
            nome:'Introdução',
            pasta: '00', 
        },
        {
            nome:'Introdução',
            pasta: '01'
        },
        {
            nome:'Introdução',
            pasta: '02',
        },
        {
            nome:'Introdução',
            pasta: '03',
        },
        {
            nome:'Introdução',
            pasta: '04',
        },
        {
            nome:'Introdução',
            pasta: '05',
        },
        {
            nome:'Introdução',
            pasta: '06',
        },
        {
            nome:'Introdução',
            pasta: '07',
        },
        {
            nome:'Introdução',
            pasta: '08',
        },
        {
            nome:'Introdução',
            pasta: '09',
        },
        {
            nome:'Introdução',
            pasta: '10',
        }
    ],
    modulos : [
        ['Introdução',{
            'Introdução' : [0, 10],
        }]
    ],
}